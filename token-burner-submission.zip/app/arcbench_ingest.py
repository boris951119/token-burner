"""ArcBench 需求树摄取（factory26 参赛适配）。

平台的输入单元是 requirements.yaml 需求树（FOLDER/ATOMIC 两级，
ATOMIC 节点与 Playwright 用例一一对应，见 ARC 仓库 README），而
token-burner 的输入是一句需求文本。本模块负责两者的翻译：

- load_requirement_tree: 定位并解析 requirements.yaml；
- render_requirement_text: 把树渲染成管线需求文本——以 FOLDER 为
  模块划分指令（对齐平台 REQ 节点，traceability 可一一映射），
  ATOMIC 场景作为验收标准原文注入，并声明平台的硬性运行契约
  （PORT 环境变量、/api/health、启动时种子数据初始化）。

测试 fixture 数据（helpers.ts 中的精确字符串）不在 yaml 里——按
ARC 官方流程，生成侧应把同目录 tests/helpers.ts 一并作为上下文，
见 render_requirement_text 的 fixture_hint 参数。
"""

from __future__ import annotations

from pathlib import Path

import yaml

_REQUIREMENT_NAMES = ("requirements.yaml", "requirements.yml")


def load_requirement_tree(requirement_dir: str | Path) -> tuple[dict, Path]:
    """从目录解析需求树，返回 (tree, yaml_path)；找不到时抛 FileNotFoundError。"""
    base = Path(requirement_dir)
    for name in _REQUIREMENT_NAMES:
        path = base / name
        if path.is_file():
            with open(path, encoding="utf-8") as fh:
                return yaml.safe_load(fh), path
    raise FileNotFoundError(f"{base} 下找不到 requirements.yaml(.yml)")


def _atomic_nodes(node: dict) -> list[dict]:
    out: list[dict] = []
    for child in node.get("children") or []:
        if child.get("type") == "ATOMIC":
            out.append(child)
        else:
            out.extend(_atomic_nodes(child))
    return out


def _render_scenario(atomic: dict) -> str:
    lines: list[str] = []
    for scenario in atomic.get("scenarios") or []:
        lines.append(f"  - 场景：{scenario.get('name', '')}")
        for step in scenario.get("steps") or []:
            lines.append(f"    {step.get('keyword', '')}: {step.get('content', '')}")
    return "\n".join(lines)


def render_folder_summary(tree: dict, *, web_port: int = 3301) -> str:
    """FOLDER 级需求摘要——规模工程（keep1 取证：32 需求全量文本令
    glm-5.3 讨论超墙钟）。讨论阶段吃摘要（架构/职责/模块地图），
    ATOMIC 明细与场景步骤不进入讨论，由拆分与模块开发阶段消费全文。

    实现：渲染全文后截取「简介 + 技术规则 1-16」头部（与全文共用
    同一份规则，永不漂移），再重建 FOLDER 摘要段（职责 + 原子标题
    清单，无场景步骤）；夹具契约原文不进摘要，仅提示其存在。
    """
    full = render_requirement_text(tree, web_port=web_port)
    marker = "功能与验收要求（模块划分必须与下列功能模块一一对应，不要合并、不要增删）："
    head = full.split(marker, 1)[0]

    lines: list[str] = [head, marker]
    folders = [
        child
        for child in tree.get("children") or []
        if child.get("type") == "FOLDER"
    ]
    atomic_total = 0
    for folder in folders:
        atomics = _atomic_nodes(folder)
        atomic_total += len(atomics)
        deps = ", ".join(folder.get("dependencies") or []) or "无"
        desc = (folder.get("description") or "").strip()
        if len(desc) > 400:
            desc = desc[:400] + "…"
        lines.append("")
        lines.append(
            f"## 模块：{folder.get('id', '')} {folder.get('name', '')}"
            f"（{len(atomics)} 条原子需求）"
        )
        lines.append(f"依赖：{deps}")
        lines.append(desc)
        for atomic in atomics:
            lines.append(f"- {atomic.get('id', '')} {atomic.get('name', '')}")
    if atomic_total:
        lines.append("")
        lines.append(
            f"共 {len(folders)} 个功能模块、{atomic_total} 条原子验收需求。"
            "以上为模块地图级摘要；每条原子需求的验收标准原文、场景步骤与"
            "种子夹具契约将在拆分与模块开发阶段提供全文。讨论阶段只做"
            "架构/职责/风险评估，不要展开单条需求的实现细节。"
        )
    return "\n".join(lines)


def render_requirement_text(
    tree: dict,
    *,
    fixture_hint: str = "",
    web_port: int = 3301,
) -> str:
    """需求树 → 管线需求文本（模块划分对齐 FOLDER，验收对齐 ATOMIC）。"""
    lines: list[str] = [
        f"开发一个完整可运行的 Web 应用：{tree.get('name', '')}。",
        (tree.get("description") or "").strip(),
        "",
        "技术栈硬性要求（优先级最高，覆盖任何「避免第三方依赖」的默认倾向）：",
        f"1. 后端必须创建真实 HTTP 服务器（推荐 Flask，或 FastAPI+uvicorn），"
        f"真实监听环境变量 PORT（缺省 {web_port}）——评测从真实浏览器发起访问；",
        "2. 严禁任何形式的 HTTP 模拟：不要写 FakeRequest / 内存请求对象 / "
        "「Server would listen」之类的打印占位——凡是没有真实 socket 监听的实现一律判失败；",
        "3. 暴露 GET /api/health，启动即可访问并返回 200；",
        "4. 前端无需 Node 构建链：由后端托管静态 HTML/CSS/JS（服务端渲染或单页均可），"
        "页面交互用原生 JS 或 CDN 引入的库完成；",
        "5. 允许并建议的第三方导入：flask、fastapi、uvicorn；密码哈希用 werkzeug 或 hashlib；"
        "数据库用 sqlite3（标准库）；",
        "6. 应用启动时初始化数据库并写入种子数据（见下文各模块描述中列明的记录），"
        "种子数据的精确字符串以下文「种子数据与测试夹具契约」为准；",
        "7. 每个功能模块必须自带 Flask Blueprint：在模块内定义 "
        "bp = Blueprint('<模块名>', __name__)，把该模块的全部 HTTP 端点"
        "（路由函数）注册在 bp 上——HTTP 接线写在本模块内（此时你对本模块"
        "端点的上下文最完整），严禁把业务模块写成纯服务函数再指望组装模块"
        "凭空推断接线；",
        "8. 应用组装职责并入最后一个功能模块（不单设组装模块）：import "
        "其余模块，逐个 app.register_blueprint(<模块>.bp)——组装因此是"
        "机械动作；同时托管各模块 static/、注册 GET /api/health、提供 "
        "create_app() 与「python -m <该模块名>」启动入口；"
        "该模块的契约 exports 必须声明 create_app（评测方依赖此约定启动）；"
        "组装必须挂载【每一个】业务 Blueprint，漏挂任何模块属于集成失败；",
        "9. 各模块契约的 exports 必须把 bp 与对外路由处理函数声明为公开导出，"
        "避免实现后再改私有化导致与测试互相矛盾。",
        "9. 含引号的正则表达式必须用双引号原始字符串书写（r\"...\"），"
        "禁止在单引号原始字符串内出现未转义的单引号——写完必须能通过语法编译；",
        "10. 第三方库只用其当前版本仍然存在的公开 API——禁止使用已在新版移除的符号"
        "（如 werkzeug.urls.url_quote）；不确定时改用 Python 标准库等价实现；",
        "11. 必须有一个模块认领「Web 界面」职责：生成完整的静态站点文件"
        "（index.html + 注册/登录/搜索/订票页面 + 原生 JS），放在该模块目录的 "
        "static/ 子目录；组装模块必须把各模块的 static/ 内容托管在站点根路径——"
        "评测从首页开始走完整用户旅程（首页可见 Register/Login 链接 → "
        "注册 → 登录 → 搜索 → 选车次 → 提交订单），缺任何页面或链接即失败；",
        "12. 每个页面表单背后必须有对应的 JSON API 端点，且页面 fetch "
        "真实调用它们（r9 实证：只有注册页面而无 POST /api/register 等 "
        "JSON 端点，评测提交表单即失败）——典型配对：注册页 ↔ "
        "POST /api/register（201/409）、登录页 ↔ POST /api/login"
        "（200/401）、搜索页 ↔ GET /api/search、订票页 ↔ POST /api/booking；"
        "注册/登录成功后页面显示用户名与 Sign out 链接，搜索后展示结果"
        "列表，可选结果进入订票页提交乘客信息；",
        "13. 搜索/列表类接口必须真实查询数据库（应用启动时写入的种子数据），"
        "严禁返回硬编码静态列表、内置降级 mock 或任何内存假数据——"
        "模块各自的内置数据必须与 data 模块的种子同源，否则判定集成失败；",
        "14. 全应用必须共用唯一数据库：数据库文件路径必须用 Path(__file__) "
        "锚定（如各模块共同引用 _shared 中的单一路径），严禁 CWD 相对路径"
        "（评测方从任意目录启动服务，相对路径会产生新的空库导致种子丢失）；"
        "禁止任何模块自建独立的 sqlite 文件——多库并存判定集成失败；",
        "15. Flask 应用级钩子（teardown_appcontext/before_request 等）必须"
        "在 create_app() 组装期间、首个请求之前一次性注册（r12 实证：在"
        "请求处理路径里惰性注册 teardown_appcontext，Flask 3 抛 "
        "AssertionError 使该接口 500）——标准模式：_shared 提供 "
        "init_app(app)，create_app() 显式调用；get_db() 只允许使用已注册"
        "的回调，严禁在请求路径上首次注册任何应用级钩子；",
        "16. 任何模块访问数据库只允许通过 _shared 的 get_db()；严禁借用"
        "其他模块的 DB 封装类或连接工具（r12 实证：auth 借用 booking 的"
        "封装类导致报错定位错乱）；表结构的唯一权威是 seed_data 模块的 "
        "DDL——任何模块不得另建同名表、不得假设 DDL 之外的列（如 users.id）；"
        "跨模块表结构漂移判定集成失败；",
        "",
        "功能与验收要求（模块划分必须与下列功能模块一一对应，不要合并、不要增删）：",
    ]

    folders = [
        child
        for child in tree.get("children") or []
        if child.get("type") == "FOLDER"
    ]
    atomic_total = 0
    for folder in folders:
        atomics = _atomic_nodes(folder)
        atomic_total += len(atomics)
        deps = ", ".join(folder.get("dependencies") or []) or "无"
        lines.append("")
        lines.append(f"## 模块：{folder.get('id', '')} {folder.get('name', '')}")
        lines.append(f"依赖：{deps}")
        lines.append((folder.get("description") or "").strip())
        for atomic in atomics:
            lines.append("")
            lines.append(
                f"### {atomic.get('id', '')} {atomic.get('name', '')}（验收标准）"
            )
            desc = (atomic.get("description") or "").strip()
            if desc:
                lines.append(desc)
            rendered = _render_scenario(atomic)
            if rendered:
                lines.append(rendered)

    if fixture_hint:
        lines.extend(
            [
                "",
                "## 种子数据与测试夹具契约",
                "端到端测试会以精确字符串断言下列夹具数据：种子数据必须与之吻合，",
                "测试自身创建的记录也使用这些字符串。以下为夹具定义原文：",
                fixture_hint,
            ]
        )

    lines.extend(
        [
            "",
            f"共 {len(folders)} 个功能模块、{atomic_total} 条原子验收需求。"
            "按下列顺序开发，最后一个模块同时承担应用组装（见技术栈要求第 8 条：逐个 register_blueprint）。",
        ]
    )
    return "\n".join(lines)


def locate_fixture(requirement_dir: str | Path) -> Path | None:
    """多布局探测 tests/helpers.ts；返回首个命中路径。

    r4 取证：平台布局是 requirements/ 与 tests/ 兄弟目录，但任务包
    变体可能把 tests/ 放在 requirement_dir 内或与之平铺——放错层级
    时静默返回空会让种子契约整体丢失（搜索/种子数据漂移的根因）。
    """
    base = Path(requirement_dir)
    candidates = (
        base / "tests" / "helpers.ts",
        base.parent / "tests" / "helpers.ts",
        base / "helpers.ts",
    )
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def load_fixture_hint(requirement_dir: str | Path) -> str:
    """读取 tests/helpers.ts 原文作为种子数据契约；不存在返回空串。"""
    located = locate_fixture(requirement_dir)
    if located is None:
        return ""
    return located.read_text(encoding="utf-8", errors="replace")[:8000]
